# simple-web-app-mvc-dotnet
Simple Web App MVC (C#, ASP.NET 7.0, MVC, Entity Framework ORM)

#### GCP (Google Cloud Platform)
https://dotnet.gcp.jammary.com/
