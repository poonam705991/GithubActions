﻿namespace SimpleWebAppMVC.Models
{
    public class About
    {
        public string AppName   { get; set; }
        public string Copyright { get; set; }
        public string Url       { get; set; }
        public string Version   { get; set; }
    }
}
